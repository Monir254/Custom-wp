;(function ($){

	$(document).ready(function(){
	    $('ul.sf-menu').superfish();
    });

})(jQuery)