<?php get_header(); ?>
    
    <div id="primary" class="content-site">
    	<main id="main" class="site-main clearfix">

			<div class="article-container clearfix">
				<?php while (have_posts()): the_post(); ?>

					<article id="post-<?php the_ID()?>" <?php post_class()?>  >
						<?php 
							the_title( '<h1 class="entry-title">', '</h1>' );
						?>

						<?php 
							$cat_list = get_the_category_list( ', ', 'webIntern' );
							printf('<span class="cat_links">Cats: %1$s</span>', $cat_list);

							$tag_list = get_the_tag_list( 'Tags:', ', ' );
							printf('<span class="tag_links">%1$s</span>', $tag_list);
						?>

						<?php  
							if(has_post_thumbnail()) {
								?>
								<div class="post-thumb">
									<?php the_post_thumbnail(); ?>
								</div>
								<?php
							}
						?>

						<?php the_content(); ?>

						<?php 
							wp_link_pages( array(
								'before' => '<div class="page_nav">' . __('Pages:', 'webIntern'),
								'after' => '</div>'
							) );
						?>

					</article>

					<div class="comment-section">
						<?php 
							if(comments_open(  )){
								comments_template();
							}
						?>
					</div>

				<?php endwhile; ?>
			</div>

    	</main>

    	<?php if(is_active_sidebar( 'wi-sidebar' )): ?>
	    	<div class="right-sidebar clearfix">
	    		<?php dynamic_sidebar( 'wi-sidebar' ); ?>
	    	</div>
    	<?php endif; ?>
    </div>
    
<?php get_footer(); ?>