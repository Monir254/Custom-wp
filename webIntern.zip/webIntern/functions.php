<?php 

function wi_setup_theme(){

    load_theme_textdomain('webIntern', get_template_directory_uri('/languages'));

    add_theme_support( 'title-tag' );

    add_theme_support( 'post-thumbnails' );

    add_theme_support( 'custom-logo', array(
        'height' => 100,
        'width'  => 250,
        'flex-width' => true,
        'flex-height' => true
    ) );

    add_theme_support( 'custom-background' );

    add_theme_support( 'automatic-feed-links' );

    add_theme_support( 'customize-selective-refresh-widgets' );

    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script' ) );

    register_nav_menus(array(
        'wi-top-menu' => __('Top menu', 'webIntern'),
        'wi-primary-menu' => __('Primary Menu', 'webIntern')
    ));

}
add_action('after_setup_theme', 'wi_setup_theme');

function wi_assets(){
    wp_enqueue_style( 'wi-google-fonts', '//fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Raleway:ital,wght@0,600;0,700;1,600;1,700&display=swap' );
    wp_enqueue_style( 'wi-fontawesome', get_template_directory_uri() . '/assets/css/font-awesome.min.css');
    wp_enqueue_style( 'wi-supperfish-css', get_template_directory_uri() . '/assets/css/superfish.css');
    wp_enqueue_style( 'wi-main-style', get_stylesheet_uri() );

    wp_enqueue_script( 'wi-superfish', get_template_directory_uri() . '/assets/js/superfish.js', array('jQuery'), '1.7.10', true );
     wp_enqueue_script( 'wi-main-js', get_template_directory_uri() . '/assets/js/scripts.js', array('jQuery'), null, true );
}
add_action('wp_enqueue_scripts', 'wi_assets');


function wi_widget_registration(){

    register_sidebar(array(
        'name' => __('Social Widgets', 'webIntern'),
        'id' => 'wi-social-widget',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>' 
    ));


    register_sidebar(array(
        'name' => __('Footer Copyright', 'webIntern'),
        'id' => 'wi-footer-copyright',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>' 
    ));

    register_sidebar(array(
        'name' => __('Sidebar', 'webIntern'),
        'id' => 'wi-sidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>' 
    ));
}
add_action('widgets_init', 'wi_widget_registration');


function wi_excerpt_length( $length ) {
    return 20;
}
add_filter( 'excerpt_length', 'wi_excerpt_length', 999 );



