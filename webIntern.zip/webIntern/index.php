<?php get_header(); ?>
    
    <div id="primary" class="content-site">
    	<main id="main" class="site-main clearfix">

    		<?php if(have_posts()): ?>

    			<div class="article-container clearfix">
    				<?php while (have_posts()): the_post(); ?>

    					<article id="post-<?php the_ID()?>" <?php post_class()?>  >
    						<?php 
    							the_title( '<h1 class="entry-title"><a href="'. esc_url( get_permalink() ) .'">', '</a></h1>' );
    						?>

    						<?php  
    							if(has_post_thumbnail()) {
    								?>
    								<div class="post-thumb">
    									<?php the_post_thumbnail(); ?>
    								</div>
    								<?php
    							}
    						?>

    						<?php the_excerpt('10'); ?>

    						<a href="<?php the_permalink(); ?>"><?php echo esc_html( 'Read More', 'webIntern' ); ?></a>

    					</article>

    				<?php endwhile; ?>
                    <?php 
                        the_posts_navigation( array(
                            'before' => '<div class="post_pagination">',
                            'after' => '</div>' 
                        ) );
                    ?>
    			</div>

    			<?php else: ?>
    				<p>No posts</p>
			<?php endif; ?>
    	</main>

    	<?php if(is_active_sidebar( 'wi-sidebar' )): ?>
	    	<div class="right-sidebar clearfix">
	    		<?php dynamic_sidebar( 'wi-sidebar' ); ?>
	    	</div>
    	<?php endif; ?>
    </div>
    
<?php get_footer(); ?>