<!DOCTYPE html>
<html lang="<?php language_attributes(); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
</head>
<body <?php body_class() ?> >
    <?php wp_body_open(); ?>
    <div class="top-header-section">
        <div class="top-header grid-container clearfix">
            <div class="top-header-left clearfix">
                <?php  
                    wp_nav_menu(array(
                        'theme_location' => 'wi-top-menu',
                        'container' => 'nav',
                        'menu_id' => 'wi-top-menu',
                        'menu_class' => 'top-menu'
                    ))
                ?>
            </div>
            <?php if(is_active_sidebar('wi-social-widget')): ?>
                <div class="top-header-right clearfix">
                    <?php dynamic_sidebar('wi-social-widget'); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="logo-section-area">
        <div class="logo-section grid-container clearfix">

            <?php if(has_custom_logo()): ?>
                <div class="logo">
                    <?php the_custom_logo(); ?>
                </div>
            <?php endif; ?>

            <?php if(is_front_page() || is_home()): ?>
                <h1><a href="<?php echo home_url(''); ?>"><?php bloginfo( 'name' ); ?></a></h1>
            <?php else: ?>
                <p><a href="<?php echo home_url(''); ?>"><?php bloginfo( 'name' ); ?></a></p>
            <?php endif; ?>

            <p><?php bloginfo( 'description' ); ?> </p>

        </div>
    </div>

    <div class="main-navigation-section">
        <div class="main-navigation grid-container clearfix">
            <?php  
                wp_nav_menu(array(
                    'theme_location' => 'wi-primary-menu',
                    'container' => 'nav',
                    'menu_id' => 'wi-primary-menu',
                    'menu_class' => 'sf-menu primary-menu'
                ))
            ?>
        </div>
    </div>

    <div id="page" class="site">
        <div id="content" class="site-content grid-container clearfix">
            
        