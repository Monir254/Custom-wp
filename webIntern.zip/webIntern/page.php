<?php get_header(); ?>
    
    <div id="primary" class="content-site">
        <main id="main" class="site-main page clearfix">
                <div class="article-container clearfix">

                    <?php while (have_posts()): the_post(); ?>
                        <div class="webInternPage">
                            <?php 
                                the_title( '<h1 class="entry-title">', '</h1>' );
                            ?>

                            <?php if(has_post_thumbnail()):  ?>

                                <div class="post-thumb">
                                    <?php the_post_thumbnail(); ?>
                                </div>

                            <?php endif; ?>

                            <?php the_content(); ?>

                            <?php 
                                wp_link_pages( array(
                                    'before' => '<div class="page_nav">' . __('Pages:', 'webIntern'),
                                    'after' => '</div>'
                                ) );
                            ?>

                        </div>

                        <div class="comment-section">
                            <?php 
                                if(comments_open(  )){
                                    comments_template();
                                }
                            ?>
                        </div>
                    <?php endwhile; ?>
                </div>
            </main>
        </div>
    
<?php get_footer(); ?>